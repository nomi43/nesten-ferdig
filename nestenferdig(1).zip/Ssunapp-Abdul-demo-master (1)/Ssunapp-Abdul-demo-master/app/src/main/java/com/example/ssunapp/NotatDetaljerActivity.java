package com.example.ssunapp;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bumptech.glide.Glide;

public class NotatDetaljerActivity extends AppCompatActivity {

    private EditText editTitle, editFag, editLarer, editDesc;
    private TextView publishedByView;
    private Button saveButton, editButton, deleteButton;
    private Noter currentNoter;
    private ImageView imageView;
    private String currentUserEmail;
    private String currentUser;
    private SharedPreferences sharedPreferences;
    private Button viewPublisherProfileButton;
    private String publisherEmail; // Email of the note's publisher


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notat_detaljer);

        initializeViews();
        retrieveIntentData();
        setupButtonListeners();
    }

    private void initializeViews() {
        imageView = findViewById(R.id.imageView);
        editTitle = findViewById(R.id.editTitle);
        editFag = findViewById(R.id.editFag);
        editLarer = findViewById(R.id.editLarer);
        editDesc = findViewById(R.id.editDesc);
        publishedByView = findViewById(R.id.publishedByView);
        saveButton = findViewById(R.id.saveButton);
        editButton = findViewById(R.id.editButton);
        deleteButton = findViewById(R.id.deleteButton);

        sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        currentUserEmail = sharedPreferences.getString("user_email", "");
        viewPublisherProfileButton = findViewById(R.id.viewPublisherProfileButton);

    }

    private void retrieveIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            int noteId = intent.getIntExtra("NOTAT_ID", -1);
            String noteTitle = intent.getStringExtra("NOTAT_TITLE");
            String noteFag = intent.getStringExtra("NOTAT_FAG");
            String noteLarer = intent.getStringExtra("NOTAT_LARER");
            String noteDesc = intent.getStringExtra("NOTAT_BESKRIVELSE");
            String noteImg = intent.getStringExtra("NOTAT_BILDE");
            String publishedBy = intent.getStringExtra("NOTAT_PUBLISHED_BY");
            publisherEmail = intent.getStringExtra("PUBLISHER_EMAIL");

            currentNoter = new Noter(noteId, noteTitle, noteFag, noteLarer, noteDesc, noteImg, publishedBy);
            setNoteDataToViews();
        }
    }

    private void setupButtonListeners() {
        editButton.setOnClickListener(v -> {
            if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
                enableEditing();
            } else {
                Toast.makeText(this, "You can only edit your own notes", Toast.LENGTH_SHORT).show();
            }
        });

        saveButton.setOnClickListener(v -> {
            if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
                saveNote();
            } else {
                Toast.makeText(this, "You can only edit your own notes", Toast.LENGTH_SHORT).show();
            }
        });

        deleteButton.setOnClickListener(v -> {
            if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
                deleteNotat();
            } else {
                Toast.makeText(this, "You can only delete your own notes", Toast.LENGTH_SHORT).show();
            }
        });

        // Listener for viewing the publisher's profile
        viewPublisherProfileButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Start PublisherProfileActivity and pass the publisher's email
                String publisherEmail = currentNoter.getPublishedBy();
                Intent intent = new Intent(NotatDetaljerActivity.this, PublisherProfileActivity.class);
                intent.putExtra("PUBLISHER_EMAIL", publisherEmail);
                startActivity(intent);
            }
        });
    }





// Implement enableEditing(), saveNote(), and deleteNotat() methods as per your requirements

    private void enableEditingOptions() {
        // Enable the edit and delete buttons only if the current user is the publisher
        if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
            editButton.setEnabled(true);
            deleteButton.setEnabled(true);
        } else {
            editButton.setEnabled(false);
            deleteButton.setEnabled(false);
        }
    }

    private void disableEditingOptions() {
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);
    }

    private void enableEditing() {
        // Enable editing fields if the current user is the publisher
        if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
            editTitle.setEnabled(true);
            editFag.setEnabled(true);
            editLarer.setEnabled(true);
            editDesc.setEnabled(true);

            // Optionally, focus on the title and show the keyboard
            editTitle.requestFocus();
            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.showSoftInput(editTitle, InputMethodManager.SHOW_IMPLICIT);

            // Adjust visibility of buttons
            saveButton.setVisibility(View.VISIBLE);
            editButton.setVisibility(View.GONE);
        } else {
            Toast.makeText(this, "You can only edit your own notes", Toast.LENGTH_SHORT).show();
        }
    }

    private void setNoteDataToViews() {
        // Setting data to views
        editTitle.setText(currentNoter.getNoter_title());
        editFag.setText(currentNoter.getNoter_fag());
        editLarer.setText(currentNoter.getNoter_larer());
        editDesc.setText(currentNoter.getNoter_des());
        publishedByView.setText("Published by: " + (currentNoter.getPublishedBy() != null ? currentNoter.getPublishedBy() : "Unknown"));

        if (currentNoter.getNoter_img() != null && !currentNoter.getNoter_img().isEmpty()) {
            Glide.with(this)
                    .load(Uri.parse(currentNoter.getNoter_img()))
                    .placeholder(R.drawable.notaking) // Replace with actual placeholder image
                    .error(R.drawable.notaking) // Replace with actual error image
                    .into(imageView);
        }
    }

    private void saveNote() {
        if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
            // Capture updated values from EditText fields
            String updatedTitle = editTitle.getText().toString();
            String updatedFag = editFag.getText().toString();
            String updatedLarer = editLarer.getText().toString();
            String updatedDesc = editDesc.getText().toString();

            // Update the currentNoter object
            currentNoter.setNoter_title(updatedTitle);
            currentNoter.setNoter_fag(updatedFag);
            currentNoter.setNoter_larer(updatedLarer);
            currentNoter.setNoter_des(updatedDesc);

            // Call the database to update the note
            DataBase db = new DataBase(NotatDetaljerActivity.this);
            boolean result = db.updateNotat(currentNoter);

            if (result) {
                Toast.makeText(this, "Note updated", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(this, "Failed to update note", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "You can only edit your own notes", Toast.LENGTH_SHORT).show();
        }
    }



    private void deleteNotat() {
        // Delete the note if the current user is the publisher
        if (currentUserEmail.equals(currentNoter.getPublishedBy())) {
            DataBase db = new DataBase(NotatDetaljerActivity.this);
            boolean result = db.deleteNotat(currentNoter.getNoter_id());

            if (result) {
                Toast.makeText(NotatDetaljerActivity.this, "Note deleted", Toast.LENGTH_SHORT).show();
                setResult(RESULT_OK);
                finish();
            } else {
                Toast.makeText(NotatDetaljerActivity.this, "Failed to delete note", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "You can only delete your own notes", Toast.LENGTH_SHORT).show();
        }
    }
}