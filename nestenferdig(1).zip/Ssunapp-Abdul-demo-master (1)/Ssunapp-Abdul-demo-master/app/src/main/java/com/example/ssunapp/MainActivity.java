package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;
import androidx.annotation.Nullable;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import android.app.Activity;
import android.content.Intent;
import android.util.Log;
import android.content.SharedPreferences;
public class MainActivity extends AppCompatActivity {
    private static final int REQUEST_CODE_FOR_NOTE_DETAILS = 2; // Or any other unique integer



    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private FloatingActionButton addButton;
    private NotaterRcvAdapter notaterRcvAdapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private DataBase sqlite;
    private ActivityResultLauncher<Intent> addNoteLauncher;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // Only set the correct layout

        initializeViews();
        setupToolbar();
        setupRecyclerView();
        setupAddButton();
        setupActivityResultLauncher();
    }




    private void initializeViews() {
        toolbar = findViewById(R.id.main_activ_toolbar);
        recyclerView = findViewById(R.id.main_activ_rsv);
        addButton = findViewById(R.id.main_activ_fbut_addnot);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);
        swipeRefreshLayout.setOnRefreshListener(this::refreshNotater);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.main_activ_toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupRecyclerView() {
        sqlite = new DataBase(this);
        ArrayList<Noter> noters = sqlite.getAllnoters();
        notaterRcvAdapter = new NotaterRcvAdapter(noters, this, new NotaterRcvAdapter.OnNoteClickListener() {
            @Override
            public void onNoteClicked(Noter note) {
                // Start NotatDetaljerActivity with the note details
                Intent intent = new Intent(MainActivity.this, NotatDetaljerActivity.class);
                intent.putExtra("NOTAT_ID", note.getNoter_id());
                intent.putExtra("NOTAT_TITLE", note.getNoter_title());
                intent.putExtra("NOTAT_FAG", note.getNoter_fag());
                intent.putExtra("NOTAT_LARER", note.getNoter_larer());
                intent.putExtra("NOTAT_BESKRIVELSE", note.getNoter_des());
                intent.putExtra("NOTAT_BILDE", note.getNoter_img());
                intent.putExtra("NOTAT_PUBLISHED_BY", note.getPublishedBy());
                Log.d("MainActivityDebug", "Note clicked: " + note.getNoter_title() + ", Published by: " + note.getPublishedBy());
                startActivity(intent);
            }
        });

        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(notaterRcvAdapter);
        recyclerView.setHasFixedSize(true);
    }



    private void setupAddButton() {
        addButton.setOnClickListener(view -> {
            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
            String currentUserName = sharedPreferences.getString("user_name", "");
            String currentUserEmail = sharedPreferences.getString("user_email", "");

            Intent intent = new Intent(getApplicationContext(), ViewNotActivity.class);
            intent.putExtra("USER_NAME", currentUserName);
            addNoteLauncher.launch(intent);
        });
    }



    private void setupActivityResultLauncher() {
        addNoteLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == Activity.RESULT_OK) {
                        refreshNotater(); // This should refresh the list of notes
                    }
                });
    }
    private void refreshNotesList() {
        ArrayList<Noter> updatedNoters = sqlite.getAllnoters();
        notaterRcvAdapter.setNotes(updatedNoters);
        notaterRcvAdapter.notifyDataSetChanged();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshNotater(); // This should also refresh the list of notes
    }


    private void refreshNotater() {
        ArrayList<Noter> updatedNoters = sqlite.getAllnoters();
        Log.d("MainActivityDebug", "Retrieved notes from DB. Size: " + updatedNoters.size());
        notaterRcvAdapter.setNotes(updatedNoters);
        notaterRcvAdapter.notifyDataSetChanged();
        swipeRefreshLayout.setRefreshing(false);
    }

    private void signOut() {
        // Clear shared preferences
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();

        // Navigate back to LoginActivity
        Intent intent = new Intent(this, LoginActivity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.menu_user_profile) {
            // Open UserProfileActivity when the user profile menu item is selected
            Intent intent = new Intent(this, UserProfileActivity.class);
            startActivity(intent);
            return true;
        } else if (id == R.id.menu_sign_out) {
            signOut();
            return true;
        }

        return super.onOptionsItemSelected(item);
    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_meny, menu);

        // Find the search item
        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        if (searchItem != null) {
            SearchView searchView = (SearchView) searchItem.getActionView();
            if (searchView != null) {
                // Set the listener for the SearchView
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        // Add your search logic here
                        notaterRcvAdapter.filter(query);
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // Update the search filter as the user types
                        notaterRcvAdapter.filter(newText);
                        return true;
                    }
                });
            } else {
                Toast.makeText(MainActivity.this, "Search View is not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Search item is not found in the menu", Toast.LENGTH_SHORT).show();
        }

        return true;
    }




}
