package com.example.ssunapp;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import java.util.ArrayList;
import java.util.List;
import android.util.Log;
import android.content.SharedPreferences;

public class NotaterRcvAdapter extends RecyclerView.Adapter<NotaterRcvAdapter.ViewHolder> {

    private List<Noter> originalList; // Original, unfiltered list of notes
    private List<Noter> filteredList; // Filtered list of notes
    private Context context;
    private OnNoteClickListener onNoteClickListener;

    public NotaterRcvAdapter(ArrayList<Noter> notes, Context context, OnNoteClickListener onNoteClickListener) {
        this.originalList = new ArrayList<>(notes);
        this.filteredList = new ArrayList<>(notes); // Initially, filtered list is same as original
        this.context = context;
        this.onNoteClickListener = onNoteClickListener;
    }

    public void setNotes(ArrayList<Noter> newNotes) {
        Log.d("AdapterDebug", "Setting new notes. Size: " + newNotes.size());
        this.originalList.clear();
        this.originalList.addAll(newNotes);
        this.filteredList.clear();
        this.filteredList.addAll(newNotes);
        notifyDataSetChanged();
    }


    public void filter(String text) {
        filteredList.clear();
        if (text.isEmpty()) {
            filteredList.addAll(originalList);
        } else {
            text = text.toLowerCase();
            for (Noter noter : originalList) {
                if (noter.getNoter_title().toLowerCase().contains(text)) {
                    filteredList.add(noter);
                }
            }
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.notat_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        // Check if the position is within the range of the filtered list
        if (position < 0 || position >= filteredList.size()) {
            Log.e("AdapterDebug", "Position out of bounds: " + position);
            return;
        }

        Noter noter = filteredList.get(position);

        // Log the binding process for debugging
        Log.d("AdapterDebug", "Binding view for position " + position + " with title: " + noter.getNoter_title());

        // Set the title and section/fag views
        holder.titleView.setText(noter.getNoter_title() != null ? noter.getNoter_title() : "Unknown Title");
        holder.fagView.setText(noter.getNoter_fag() != null ? noter.getNoter_fag() : "Unknown Section");

        // Set the publisher's name
        holder.publisherView.setText("Published by: " + (noter.getPublishedBy() != null ? noter.getPublishedBy() : "Unknown Publisher"));

        // Check for image URL and load it if available
        if (noter.getNoter_img() != null && !noter.getNoter_img().isEmpty()) {
            Glide.with(context)
                    .load(Uri.parse(noter.getNoter_img()))
                    .placeholder(R.drawable.notaking) // Placeholder image while loading
                    .error(R.drawable.notaking)       // Image to display in case of error
                    .into(holder.imageView);
        } else {
            // Use a default image if there is no image URL
            holder.imageView.setImageResource(R.drawable.notaking);
        }

        // Set the click listener for the item view
        holder.itemView.setOnClickListener(v -> {
            if (onNoteClickListener != null) {
                onNoteClickListener.onNoteClicked(noter);
            }
        });
    }

    public interface OnNoteClickListener {
        void onNoteClicked(Noter note);
    }



    @Override
    public int getItemCount() {
        return filteredList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        ImageView imageView;
        TextView titleView, fagView, publisherView; // Add publisherView here

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            imageView = itemView.findViewById(R.id.cardv_img);
            titleView = itemView.findViewById(R.id.cardv_tv_title);
            fagView = itemView.findViewById(R.id.cardv_tv_section);
            publisherView = itemView.findViewById(R.id.cardv_tv_publisher); // Initialize publisherView
            itemView.setOnClickListener(this);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            if (position != RecyclerView.NO_POSITION) {
                Noter noter = filteredList.get(position);
                Intent intent = new Intent(context, NotatDetaljerActivity.class);
                intent.putExtra("NOTAT_ID", noter.getNoter_id());
                intent.putExtra("NOTAT_TITLE", noter.getNoter_title());
                intent.putExtra("NOTAT_FAG", noter.getNoter_fag());
                intent.putExtra("NOTAT_LARER", noter.getNoter_larer());
                intent.putExtra("NOTAT_BESKRIVELSE", noter.getNoter_des());
                intent.putExtra("NOTAT_BILDE", noter.getNoter_img());
                intent.putExtra("NOTAT_PUBLISHED_BY", noter.getPublishedBy()); // Add this line

                context.startActivity(intent);
            }
        }

    }
}
