package com.example.ssunapp;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import android.content.SharedPreferences;

public class UserProfileActivity extends AppCompatActivity {

    EditText etName, etEmail, etPhone;
    Button btnSave;
    DataBase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_profile);

        // Initialize views
        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        etPhone = findViewById(R.id.etPhone);
        btnSave = findViewById(R.id.btnSave);

        // Initialize database
        database = new DataBase(this);

        // Load user data from database
        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
        String userEmail = sharedPreferences.getString("user_email", "");
        User currentUser = database.getUserByEmail(userEmail);
        if (currentUser != null) {
            etName.setText(currentUser.getUser_name());
            etEmail.setText(currentUser.getUser_mail());
            etPhone.setText(currentUser.getUserPhone());
        } else {
            Toast.makeText(this, "User not found", Toast.LENGTH_SHORT).show();
        }

        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String name = etName.getText().toString();
                String email = etEmail.getText().toString();
                String phone = etPhone.getText().toString();

                // Validate fields before updating
                if (name.isEmpty() || phone.isEmpty()) {
                    Toast.makeText(UserProfileActivity.this, "Name and phone cannot be empty", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (!email.equals(userEmail)) {
                    Toast.makeText(UserProfileActivity.this, "Email cannot be changed", Toast.LENGTH_SHORT).show();
                    return;
                }

                User updatedUser = new User(name, email, phone);
                boolean success = database.updateUser(updatedUser);
                if (success) {
                    Toast.makeText(UserProfileActivity.this, "Profile Updated", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(UserProfileActivity.this, "Update Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }
}
