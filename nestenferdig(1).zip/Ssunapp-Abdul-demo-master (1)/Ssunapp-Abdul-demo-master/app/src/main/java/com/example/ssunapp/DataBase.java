package com.example.ssunapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DataBase extends SQLiteOpenHelper {


    public final static String DB_NAME = "ssun.sql";
    public final static int DB_VERSION = 4;
    public static final String user_tab_phone = "user_phone"; // New column for phone number
    public static final String noter_tab_published_by = "published_by"; // New column for publisher

    public static final String user_tab_name = "user";
    public static final String user_tab_id = "id_user";
    public static final String user_tab_username = "user_name";
    public static final String user_tab_usermail = "user_mail";
    public static final String user_tab_password = "user_pass";
    public static final String noter_tab_name = "noter";
    public static final String noter_tab_id_noter = "noter_id";
    public static final String noter_tab_title = "noter_title";
    public static final String noter_tab_fag = "noter_fag";
    public static final String noter_tab_larer = "noter_larer";
    public static final String noter_tab_description = "noter_des";

    public static final String noter_tab_img = "noter_img";

    //---------------------------------------------------------------------------------------------

    public DataBase(@Nullable Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }


    @Override
    public void onCreate(SQLiteDatabase db) {

        // Modify the user table creation query to include the phone number
        db.execSQL("CREATE TABLE " + user_tab_name + "("
                + user_tab_id + " INTEGER PRIMARY KEY AUTOINCREMENT,"
                + user_tab_username + " TEXT,"
                + user_tab_usermail + " TEXT,"
                + user_tab_password + " TEXT,"
                + user_tab_phone + " TEXT)"); // New column for phone number

        // Modify the noter table creation query to include the published by field
        db.execSQL("CREATE TABLE " + noter_tab_name + "("
                + noter_tab_id_noter + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + noter_tab_title + " TEXT,"
                + noter_tab_fag + " TEXT,"
                + noter_tab_larer + " TEXT,"
                + noter_tab_description + " TEXT,"
                + noter_tab_img + " TEXT,"
                + "publishedBy TEXT)"); // Corrected this line

    }



    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        if (oldVersion < 4) { // Assuming DB_VERSION is now 4
            db.execSQL("ALTER TABLE " + noter_tab_name + " ADD COLUMN publishedBy TEXT DEFAULT ''");

            // Check if the user table already has the 'user_phone' column
            if (!isColumnExist(db, user_tab_name, user_tab_phone)) {
                // Add the 'user_phone' column to the 'user_tab_name' table
                db.execSQL("ALTER TABLE " + user_tab_name + " ADD COLUMN " + user_tab_phone + " TEXT DEFAULT ''");
            }

            // Check if the noter table already has the 'publishedBy' column
            if (!isColumnExist(db, noter_tab_name, noter_tab_published_by)) {
                // Add the 'publishedBy' column to the 'noter_tab_name' table
                db.execSQL("ALTER TABLE " + noter_tab_name + " ADD COLUMN " + noter_tab_published_by + " TEXT DEFAULT ''");
            }
        }
    }

    /**
     * Checks if a column exists in a table.
     * @param db The database.
     * @param tableName The name of the table.
     * @param columnName The name of the column to check.
     * @return True if the column exists, false otherwise.
     */
    private boolean isColumnExist(SQLiteDatabase db, String tableName, String columnName) {
        Cursor cursor = null;
        try {
            cursor = db.rawQuery("PRAGMA table_info(" + tableName + ")", null);
            int nameColumnIndex = cursor.getColumnIndexOrThrow("name");
            while (cursor.moveToNext()) {
                String name = cursor.getString(nameColumnIndex);
                if (name.equals(columnName)) {
                    return true;
                }
            }
            return false;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            if (cursor != null && !cursor.isClosed()) {
                cursor.close();
            }
        }
    }


    public boolean Insert_user(User user) {

        SQLiteDatabase db_user = getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(user_tab_username, user.getUser_name());
        contentValues.put(user_tab_usermail, user.getUser_mail());
        contentValues.put(user_tab_password, user.getUser_pass());
        Log.d("DataBaseDebug", "Inserting Note with Publisher: " + contentValues.getAsString("publishedBy"));
        long result = db_user.insert(user_tab_name, null, contentValues);
        return result != -1;


    }


    public boolean Insert_not(Noter noter) {
        SQLiteDatabase db_not = null;
        try {
            db_not = getWritableDatabase();
            ContentValues contentValues = new ContentValues();
            contentValues.put(noter_tab_title, noter.getNoter_title());
            contentValues.put(noter_tab_fag, noter.getNoter_fag());
            contentValues.put(noter_tab_larer, noter.getNoter_larer());
            contentValues.put(noter_tab_description, noter.getNoter_des());
            contentValues.put("publishedBy", noter.getPublishedBy()); // Add this line

            if (noter.getNoter_img() != null && !noter.getNoter_img().isEmpty()) {
                contentValues.put(noter_tab_img, noter.getNoter_img());
            }

            long result = db_not.insert(noter_tab_name, null, contentValues);
            return result != -1;
        } catch (Exception e) {
            Log.e("Database", "Error inserting noter", e);
            return false;
        } finally {
            if (db_not != null) {
                db_not.close();
            }
        }
    }





    public ArrayList<String> getAllusers() {
        ArrayList<String> useres = new ArrayList<>();
        SQLiteDatabase db_user = this.getReadableDatabase();
        Cursor res_user = db_user.rawQuery(" SELECT * FROM " + user_tab_name, null);
        res_user.moveToFirst();

        do {
            String useremail = res_user.getString(2);
            String userpassword = res_user.getString(3);
            //User user = new User(useremail, userpassword);
            useres.add(useremail);
            useres.add(userpassword);
            res_user.moveToNext();

        } while (res_user.moveToNext());
        {
            res_user.close();

        }
        return useres;


    }


    //-----------------------------------------------------------------------------------------

    /* public long get_noter_count() {
        SQLiteDatabase db_noter = getReadableDatabase();
        return DatabaseUtils.queryNumEntries(db_noter, noter_tab_name);

    }*/

    public ArrayList<Noter> getAllnoters() {
        ArrayList<Noter> noters = new ArrayList<>();
        SQLiteDatabase dbNoter = this.getReadableDatabase();
        Cursor resNoter = dbNoter.rawQuery("SELECT * FROM " + noter_tab_name, null);

        if (resNoter != null && resNoter.moveToFirst()) {
            do {
                int id = resNoter.getInt(0);
                String noterTitle = resNoter.getString(1);
                String noterFag = resNoter.getString(2);
                String noterLarer = resNoter.getString(3);
                String noterDesc = resNoter.getString(4);
                String noterImg = resNoter.getString(5);
                String publishedBy = resNoter.getString(6); // Make sure this is the correct column index
                Noter noter = new Noter(id, noterTitle, noterFag, noterLarer, noterDesc, noterImg, publishedBy);

                Log.d("DataBaseDebug", "Retrieved Note: " + noterTitle + ", Published by: " + publishedBy);

                noters.add(noter);
            } while (resNoter.moveToNext());
            resNoter.close();
        }

        return noters;
    }




    //Oppdatering av notater
    public boolean updateNotat(Noter noter) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(noter_tab_title, noter.getNoter_title());
        contentValues.put(noter_tab_fag, noter.getNoter_fag());
        contentValues.put(noter_tab_larer, noter.getNoter_larer());
        contentValues.put(noter_tab_description, noter.getNoter_des());
        // Assuming there are no other fields to update like image or publishedBy

        int rowsAffected = db.update(noter_tab_name, contentValues, noter_tab_id_noter + " = ?", new String[]{String.valueOf(noter.getNoter_id())});
        db.close();

        return rowsAffected > 0;
    }

    // Inside your DataBase class

    public boolean updateUser(User user) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(user_tab_username, user.getUser_name());
        contentValues.put(user_tab_usermail, user.getUser_mail());
        contentValues.put("user_phone", user.getUserPhone()); // Assuming this is the column name in your database

        int updateResult = db.update(user_tab_name, contentValues, user_tab_usermail + " = ?", new String[]{user.getUser_mail()});
        db.close();
        return updateResult > 0;
    }


    public User getUserByEmail(String email) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(user_tab_name, new String[]{user_tab_id, user_tab_username, user_tab_usermail, "user_phone"}, user_tab_usermail + "=?", new String[]{email}, null, null, null);

        if (cursor != null && cursor.moveToFirst()) {
            String userName = cursor.getString(1);
            String userMail = cursor.getString(2);
            String userPhone = cursor.getString(3);
            cursor.close();
            return new User(userName, userMail, userPhone);
        }
        if (cursor != null) {
            cursor.close();
        }
        return null;
    }



    public boolean deleteNotat(int noterId) {
        SQLiteDatabase db_not = this.getWritableDatabase();
        // Delete the note where the ID matches
        int result = db_not.delete(noter_tab_name, noter_tab_id_noter + " = ?", new String[]{String.valueOf(noterId)});
        db_not.close();
        return result > 0;
    }


// avdeling+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++


    public boolean login_user(String usermail, String password) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + user_tab_name + " WHERE " + user_tab_usermail + "=? AND " + user_tab_password + "=?", new String[]{usermail, password});
        boolean exists = cursor.getCount() > 0;
        cursor.close();
        return exists;
    }



    }

//end of class--------------------------------------------------









