package com.example.ssunapp;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class PublisherProfileActivity extends AppCompatActivity {

    TextView tvPublisherName, tvPublisherEmail, tvPublisherPhone;
    ImageView ivPublisherProfilePic;
    DataBase database;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_publisher_profile);

        // Initialize views
        tvPublisherName = findViewById(R.id.tvPublisherName);
        tvPublisherEmail = findViewById(R.id.tvPublisherEmail);
        tvPublisherPhone = findViewById(R.id.tvPublisherPhone);
        ivPublisherProfilePic = findViewById(R.id.ivPublisherProfilePic);

        // Initialize database
        database = new DataBase(this);

        // Retrieve the publisher's email passed from NotatDetaljerActivity
        String publisherEmail = getIntent().getStringExtra("PUBLISHER_EMAIL");

        if (publisherEmail != null) {
            User publisherUser = database.getUserByEmail(publisherEmail);
            if (publisherUser != null) {
                // Display the publisher's profile info
                tvPublisherName.setText(publisherUser.getUser_name());
                tvPublisherEmail.setText(publisherUser.getUser_mail());
                tvPublisherPhone.setText(publisherUser.getUserPhone());
                // Load publisher's profile picture if available
                // ivPublisherProfilePic.setImageResource(...) or use Glide/Picasso
            } else {
                // Handle the case where the user is not found
                // Show a message or perform some other action
            }
        }
    }
}
