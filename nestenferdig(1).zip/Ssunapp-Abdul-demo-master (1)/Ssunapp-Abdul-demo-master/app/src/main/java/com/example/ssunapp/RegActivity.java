package com.example.ssunapp;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class RegActivity extends AppCompatActivity {

    EditText reg_username, reg_mail, reg_pass;
    DataBase dbsqlite;
    Button signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        dbsqlite = new DataBase(this);
        reg_username = findViewById(R.id.reg_et_name);
        reg_mail = findViewById(R.id.reg_et_mail);
        reg_pass = findViewById(R.id.reg_et_pass);
        signup = findViewById(R.id.reg_btn_signup);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user_name = reg_username.getText().toString().trim();
                String user_mail = reg_mail.getText().toString().trim();
                String user_pass = reg_pass.getText().toString().trim();

                if (user_name.isEmpty() || user_mail.isEmpty() || user_pass.isEmpty()) {
                    Toast.makeText(getApplicationContext(), "All fields are required", Toast.LENGTH_SHORT).show();
                } else {
                    User record = new User(user_name, user_mail, user_pass);

                    boolean res = dbsqlite.Insert_user(record);
                    if (res) {
                        // Save email and name in shared preferences
                        SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref", MODE_PRIVATE);
                        SharedPreferences.Editor editor = sharedPreferences.edit();
                        editor.putString("user_email", user_mail);
                        editor.putString("user_name", user_name); // Save the user's name
                        editor.apply();

                        Toast.makeText(getApplicationContext(), "Registration Successful", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(getApplicationContext(), "Registration Failed", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
}
